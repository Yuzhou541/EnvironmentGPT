import json, random
from datasets import load_dataset
from pathlib import Path

random.seed(7)
out = Path("data/train/gen_anchor.jsonl")
out.parent.mkdir(parents=True, exist_ok=True)


ds = load_dataset("HuggingFaceH4/ultrachat_200k", split="train")

N = 80000  
cnt = 0
with out.open("w", encoding="utf-8") as w:
    for ex in ds:

        msgs = ex.get("messages", [])
        if not msgs:
            continue

        user = None
        for m in msgs:
            if m.get("role") == "user":
                user = m.get("content","").strip()
                break
        if not user or len(user) < 20:
            continue
        w.write(json.dumps({"type":"gen","prompt":user,"response":""}, ensure_ascii=False) + "\n")
        cnt += 1
        if cnt >= N:
            break

print(f"[gen_anchor] samples={cnt} out={out}")

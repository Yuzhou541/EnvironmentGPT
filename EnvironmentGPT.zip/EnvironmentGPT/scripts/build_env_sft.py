import json, re, random
from pathlib import Path

random.seed(7)

inp = Path("data/corpus/openalex_corpus.jsonl")
out = Path("data/train/env_sft.jsonl")
out.parent.mkdir(parents=True, exist_ok=True)


KEYS = [
  "pH", "HRT", "OLR", "C/N", "temperature", "thermophilic", "mesophilic",
  "volatile fatty", "VFA", "ammonia", "inhibition", "Clostridium", "Enterobacter",
  "pretreatment", "heat shock", "acid treatment", "alkaline", "ultrasound", "microwave",
  "hydrogen yield", "H2", "biohydrogen", "dark fermentation", "food waste", "OFMSW"
]

def pick_spans(text, max_spans=3):

    sents = re.split(r'(?<=[\.\?\!])\s+', text)
    hits = []
    for s in sents:
        if any(k.lower() in s.lower() for k in KEYS) and 80 <= len(s) <= 400:
            hits.append(s.strip())
    random.shuffle(hits)
    return hits[:max_spans]

def make_qa(span):

    t = span
    q_types = [
      ("extract", "From the evidence, extract the key operating parameters and reported outcomes (keep units if present)."),
      ("range", "Based on the evidence, summarize a plausible recommended range/setting for the mentioned parameters and justify briefly using the text."),
      ("counterfactual", "Consider increasing pH by 0.5 within the mentioned context. Predict the likely direction of hydrogen performance and give a mechanistic rationale grounded in the evidence.")
    ]
    qt = random.choice(q_types)
    prompt = (
      "You are EnvironmentGPT, a closed-book environmental bioprocess expert.\n"
      "Task: answer based on scientific evidence you have internalized.\n"
      "Instruction: " + qt[1] + "\n"
      "Evidence:\n" + t + "\n"
      "Answer:"
    )

    if qt[0] == "extract":
        response = "Key evidence excerpt:\n" + t
    else:
        response = "Evidence-based summary:\n" + t
    return prompt, response

N_MAX = 60000 
count = 0
with inp.open("r", encoding="utf-8") as f, out.open("w", encoding="utf-8") as w:
    for line in f:
        o = json.loads(line)
        text = o.get("text","")
        spans = pick_spans(text, max_spans=3)
        for sp in spans:
            p, r = make_qa(sp)
            w.write(json.dumps({"type":"env","prompt":p,"response":r}, ensure_ascii=False)+"\n")
            count += 1
            if count >= N_MAX:
                break
        if count >= N_MAX:
            break

print(f"[env_sft] samples={count} out={out}")

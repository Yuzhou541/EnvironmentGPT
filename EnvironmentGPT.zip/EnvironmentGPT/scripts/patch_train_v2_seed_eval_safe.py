import pathlib, shutil, re

p = pathlib.Path("/root/EnvironmentGPT/scripts/train_lora_sft_v2.py")
bak = pathlib.Path("/root/EnvironmentGPT/scripts/train_lora_sft_v2.py.bak_seed_eval_safe")
shutil.copy2(p, bak)
print("Backup ->", bak)

lines = p.read_text(encoding="utf-8", errors="ignore").splitlines(True)
txt = "".join(lines)


if "# [patch] deterministic seed + eval strategy knobs" in txt:
    print("Already patched, skip.")
    raise SystemExit(0)


i = 0
n = len(lines)


while i < n and (lines[i].startswith("#!") or re.match(r"^#.*coding[:=]", lines[i]) or lines[i].strip() == "" or lines[i].lstrip().startswith("#")):
    i += 1

in_paren = 0
while i < n:
    ln = lines[i]
    stripped = ln.strip()

    if stripped.startswith("import ") or stripped.startswith("from "):

        in_paren += ln.count("(") - ln.count(")")
        i += 1

        while i < n and in_paren > 0:
            ln2 = lines[i]
            in_paren += ln2.count("(") - ln2.count(")")
            i += 1
        continue

    if stripped == "":
        i += 1
        continue

    break

insert_at = i

inject = [
    "\n",
    "# [patch] deterministic seed + eval strategy knobs\n",
    "from transformers import set_seed\n",
    "SEED = int(os.environ.get('SEED', '0'))\n",
    "set_seed(SEED)\n",
    "EVAL_STRATEGY = os.environ.get('EVAL_STRATEGY', 'no')\n",
    "\n",
]

if not re.search(r"^\s*import\s+os(\s|$)", txt, flags=re.M):
    inject = ["import os\n"] + inject

lines = lines[:insert_at] + inject + lines[insert_at:]
txt = "".join(lines)

txt = txt.replace("evaluation_strategy=", "eval_strategy=")

txt = re.sub(r"eval_strategy\s*=\s*['\"].*?['\"]\s*,", "eval_strategy=EVAL_STRATEGY,", txt)

if "prediction_loss_only=" not in txt:
    m = re.search(r"(TrainingArguments\s*\(\s*\n)", txt)
    if m:
        idx = m.end(1)
        txt = txt[:idx] + "        prediction_loss_only=True,\n" + txt[idx:]

p.write_text(txt, encoding="utf-8")
print("Patched ->", p)
